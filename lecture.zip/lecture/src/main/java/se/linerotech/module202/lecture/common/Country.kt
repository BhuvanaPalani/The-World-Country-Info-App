package se.linerotech.module202.lecture.common

data class Country(
    val name: String,
    val flagUrl: String
)
